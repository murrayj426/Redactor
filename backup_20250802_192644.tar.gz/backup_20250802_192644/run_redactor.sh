#!/bin/bash
cd /Users/jeremymurray/Projects/redactor
/Users/jeremymurray/Library/Python/3.9/bin/streamlit run gui.py
